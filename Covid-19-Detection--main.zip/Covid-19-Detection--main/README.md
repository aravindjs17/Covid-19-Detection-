Dataset is available in kaggle(Covid-19 chest x-ray)
